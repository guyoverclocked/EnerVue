import mysql.connector
from mysql.connector import Error

db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'nambi1298'
}

# SQL commands to create database and tables
CREATE_DB_QUERY = "CREATE DATABASE IF NOT EXISTS enervue_db"

CREATE_USERS_TABLE = """
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
"""

try:
    # First connect without database to create it
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    
    # Create database
    cursor.execute(CREATE_DB_QUERY)
    print("Database created successfully")
    
    # Connect to the new database
    db_config['database'] = 'enervue_db'
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    
    # Create tables
    cursor.execute(CREATE_USERS_TABLE)
    print("Users table created successfully")
    
    conn.commit()

except Error as err:
    print(f"Error: {err}")

finally:
    if 'conn' in locals() and conn.is_connected():
        cursor.close()
        conn.close()
        print("MySQL connection closed")