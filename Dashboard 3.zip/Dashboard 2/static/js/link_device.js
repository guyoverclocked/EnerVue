document.addEventListener('DOMContentLoaded', function() {
    const authForm = document.getElementById('auth-form');
    const configForm = document.getElementById('config-form');
    const stepIndicators = document.querySelectorAll('.step');

    // Handle first form (authentication)
    authForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
            const deviceId = document.getElementById('device-id').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            const response = await fetch('/verify-user', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    device_id: deviceId,
                    email: email,
                    password: password
                })
            });

            const result = await response.json();
            
            if (result.success) {
                // Move to next step
                authForm.classList.remove('active');
                configForm.classList.add('active');
                stepIndicators[0].classList.remove('active');
                stepIndicators[1].classList.add('active');
            } else {
                const flashMessages = document.querySelector('.flash-messages');
                flashMessages.innerHTML = `
                    <div class="alert alert-warning">
                        ${result.message}
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error:', error);
            const flashMessages = document.querySelector('.flash-messages');
            flashMessages.innerHTML = `
                <div class="alert alert-warning">
                    An error occurred. Please try again.
                </div>
            `;
        }
    });

    // Handle second form (device configuration)
    configForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
            const deviceId = document.getElementById('device-id').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const blinksPerUnit = parseFloat(document.getElementById('blinks').value);
            const billingDate = document.getElementById('last-billing').value;
            const billingMonth = parseInt(billingDate.split('-')[1]);

            const data = {
                device_id: deviceId,
                email: email,
                password: password,
                blinks_per_unit: blinksPerUnit,
                billing_month: billingMonth
            };

            const response = await fetch('/link-device', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            
            if (result.success) {
                const flashMessages = document.querySelector('.flash-messages');
                flashMessages.innerHTML = `
                    <div class="alert alert-success">
                        ${result.message}. Redirecting to home...
                    </div>
                `;
                
                setTimeout(() => {
                    window.location.href = '/';
                }, 2000);
            } else {
                const flashMessages = document.querySelector('.flash-messages');
                flashMessages.innerHTML = `
                    <div class="alert alert-warning">
                        ${result.message}
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error:', error);
            const flashMessages = document.querySelector('.flash-messages');
            flashMessages.innerHTML = `
                <div class="alert alert-warning">
                    An error occurred. Please try again.
                </div>
            `;
        }
    });

    // Handle back button
    window.previousStep = function() {
        configForm.classList.remove('active');
        authForm.classList.add('active');
        stepIndicators[1].classList.remove('active');
        stepIndicators[0].classList.add('active');
    };
});