document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('usageChart').getContext('2d');
    
    const data = {
        labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '23:59'],
        datasets: [{
            label: 'Energy Usage (kWh)',
            data: [0.2, 0.4, 0.1, 0.3, 0.5, 0.2, 0.4],
            borderColor: '#3498db',
            backgroundColor: 'rgba(52, 152, 219, 0.1)',
            tension: 0.4,
            fill: true
        }]
    };

    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(0, 0, 0, 0.05)'
                },
                ticks: {
                    maxTicksLimit: 5 // Limit the number of Y-axis ticks
                }
            },
            x: {
                grid: {
                    color: 'rgba(0, 0, 0, 0.05)'
                },
                ticks: {
                    maxTicksLimit: 6 // Limit the number of X-axis ticks
                }
            }
        },
        plugins: {
            legend: {
                display: false
            }
        },
        interaction: {
            mode: 'nearest',
            axis: 'x',
            intersect: false
        }
    };

    let usageChart = new Chart(ctx, {
        type: 'line',
        data: data,
        options: chartOptions
    });

    // Improved mobile sidebar handling
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    
    // Create overlay element
    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    document.body.appendChild(overlay);

    // Improved sidebar toggle with overlay
    sidebarToggle.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleSidebar();
    });

    function toggleSidebar() {
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
        document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
    }

    // Close sidebar when clicking overlay
    overlay.addEventListener('click', function() {
        toggleSidebar();
    });

    // Handle touch events for better mobile interaction
    let touchStartX = 0;
    let touchEndX = 0;

    document.addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
    }, false);

    document.addEventListener('touchend', function(e) {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    }, false);

    function handleSwipe() {
        const swipeThreshold = 50;
        const difference = touchEndX - touchStartX;

        if (Math.abs(difference) < swipeThreshold) return;

        if (difference > 0 && touchStartX < 50) {
            // Swipe right from left edge
            sidebar.classList.add('active');
            overlay.classList.add('active');
        } else if (difference < 0 && sidebar.classList.contains('active')) {
            // Swipe left when sidebar is open
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
        }
    }

    // Optimize chart for mobile
    function updateChartForMobile() {
        const isMobile = window.innerWidth <= 768;
        
        if (isMobile) {
            chartOptions.scales.x.ticks = {
                maxTicksLimit: 6,
                maxRotation: 0,
                minRotation: 0,
                font: {
                    size: 10
                }
            };
            
            chartOptions.scales.y.ticks = {
                maxTicksLimit: 5,
                font: {
                    size: 10
                }
            };

            // Simplify labels for mobile
            data.labels = ['12am', '4am', '8am', '12pm', '4pm', '8pm', '12am'];
        }
        
        usageChart.update('none'); // Update without animation for better performance
    }

    // Debounced resize handler
    let resizeTimeout;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(function() {
            updateChartForMobile();
        }, 250);
    });

    // Initial mobile optimization
    updateChartForMobile();
});
