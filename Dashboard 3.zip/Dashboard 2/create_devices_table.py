import mysql.connector
from mysql.connector import Error
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def create_devices_table():
    """
    Create the devices table in the enervue_db database
    """
    config = {
        'host': os.getenv('DB_HOST', 'localhost'),
        'user': os.getenv('DB_USER', 'root'),
        'password': os.getenv('DB_PASSWORD', ''),
        'database': 'enervue_db'
    }

    try:
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor()

        # Drop the table if it exists (for clean recreation)
        cursor.execute("DROP TABLE IF EXISTS devices")

        # Create devices table with exactly matching email type
        cursor.execute("""
            CREATE TABLE devices (
                device_id VARCHAR(36) PRIMARY KEY,
                email VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
                password VARCHAR(255) NOT NULL,
                blinks_per_unit FLOAT NOT NULL,
                last_billing_month INT NOT NULL,
                status ENUM('active', 'inactive') DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_email (email),
                INDEX idx_status (status),
                CONSTRAINT chk_billing_month CHECK (last_billing_month BETWEEN 1 AND 12),
                CONSTRAINT chk_blinks_per_unit CHECK (blinks_per_unit > 0),
                CONSTRAINT fk_user_email FOREIGN KEY (email) 
                    REFERENCES users(email) 
                    ON DELETE CASCADE 
                    ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
        """)

        print("Devices table created successfully in enervue_db!")

        # Show table structure
        print("\nDevices Table Structure:")
        cursor.execute("DESCRIBE devices")
        for column in cursor.fetchall():
            print(f"- {column[0]}: {column[1]}")

    except Error as e:
        print(f"Error: {e}")

    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals() and conn.is_connected():
            conn.close()
            print("\nDatabase connection closed.")

def check_users_table():
    """
    Check the structure of the existing users table
    """
    config = {
        'host': os.getenv('DB_HOST', 'localhost'),
        'user': os.getenv('DB_USER', 'root'),
        'password': os.getenv('DB_PASSWORD', ''),
        'database': 'enervue_db'
    }

    try:
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor()

        print("\nChecking users table structure:")
        cursor.execute("DESCRIBE users")
        columns = cursor.fetchall()
        for column in columns:
            print(f"- {column[0]}: {column[1]}")
            
        cursor.execute("""
            SELECT COLUMN_NAME, CHARACTER_SET_NAME, COLLATION_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = 'enervue_db' 
            AND TABLE_NAME = 'users' 
            AND COLUMN_NAME = 'email'
        """)
        email_info = cursor.fetchone()
        if email_info:
            print(f"\nEmail column details:")
            print(f"Character set: {email_info[1]}")
            print(f"Collation: {email_info[2]}")

    except Error as e:
        print(f"Error: {e}")
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals() and conn.is_connected():
            conn.close()

if __name__ == "__main__":
    while True:
        print("\nEnervue_DB Devices Table Setup")
        print("1. Check Users Table Structure")
        print("2. Create/Update Devices Table")
        print("3. Exit")
        
        choice = input("Enter your choice (1-3): ")
        
        if choice == '1':
            check_users_table()
        elif choice == '2':
            create_devices_table()
        elif choice == '3':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.") 