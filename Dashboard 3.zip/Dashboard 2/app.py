from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from functools import wraps
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash
import os
import csv
from datetime import datetime
import uuid  # For UUID validation

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Required for session and flash messages

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'nambi1298',
    'database': 'enervue_db'
}

# Database connection helper
def get_db_connection():
    try:
        conn = mysql.connector.connect(**db_config)
        print("Database connection successful!")
        return conn
    except mysql.connector.Error as err:
        print(f"Database connection failed: {err}")
        return None

# Test database connection on startup
with get_db_connection() as conn:
    if conn:
        print("Database connection test successful!")
    else:
        print("WARNING: Could not connect to database!")

# Login decorator to protect routes
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Routes
@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/')
def root():
    print("Root route accessed")
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    print(f"Login route accessed with method: {request.method}")
    if request.method == 'POST':
        print("Login POST request received")
        print(f"Form data: {request.form}")
        return login_post()
    return render_template('login.html')

@app.route('/login/post', methods=['POST'])
def login_post():
    email = request.form.get('login-email')
    password = request.form.get('login-password')
    remember = True if request.form.get('remember') else False
    
    print(f"Login attempt for email: {email}")

    conn = get_db_connection()
    if not conn:
        flash('Database connection error')
        return redirect(url_for('login'))

    cursor = conn.cursor(dictionary=True)
    
    try:
        cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
        user = cursor.fetchone()
        
        if not user:
            print("User not found")
            flash('User not found')
            return redirect(url_for('login'))
        
        if not check_password_hash(user['password'], password):
            print("Invalid password")
            flash('Invalid password')
            return redirect(url_for('login'))

        print("Login successful!")
        session['user_id'] = user['id']
        session['user_name'] = user['name']
        if remember:
            session.permanent = True
        return redirect(url_for('index'))
        
    except mysql.connector.Error as err:
        print(f"Database error during login: {err}")
        flash('An error occurred. Please try again.')
        return redirect(url_for('login'))
    finally:
        cursor.close()
        conn.close()

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    print(f"Signup route accessed with method: {request.method}")
    if request.method == 'POST':
        print("Signup POST request received")
        print(f"Form data: {request.form}")
        return signup_post()
    return render_template('login.html')

@app.route('/signup/post', methods=['POST'])
def signup_post():
    email = request.form.get('signup-email')
    name = request.form.get('signup-name')
    password = request.form.get('signup-password')
    confirm = request.form.get('signup-confirm')
    
    print(f"Signup attempt for email: {email}")

    # Validate password match
    if password != confirm:
        print("Passwords don't match")
        flash("Passwords don't match")
        return redirect(url_for('login'))

    conn = get_db_connection()
    if not conn:
        flash('Database connection error')
        return redirect(url_for('login'))

    cursor = conn.cursor(dictionary=True)
    
    try:
        # Check if user exists
        cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
        if cursor.fetchone():
            print("Email already exists")
            flash('Email address already exists')
            return redirect(url_for('login'))

        # Create new user with correct hash method
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')  # Changed this line
        cursor.execute('INSERT INTO users (email, name, password) VALUES (%s, %s, %s)',
                      (email, name, hashed_password))
        conn.commit()
        print("User created successfully!")
        flash('Successfully registered! Please login.')
        return redirect(url_for('login'))
        
    except mysql.connector.Error as err:
        conn.rollback()
        print(f"Database error during signup: {err}")
        flash('An error occurred. Please try again.')
        return redirect(url_for('login'))
    finally:
        cursor.close()
        conn.close()

@app.route('/logout')
@login_required
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        # Add your password reset logic here
        flash('If an account exists with this email, you will receive a password reset link.')
        return redirect(url_for('login'))
    return render_template('forgot_password.html')

# Error handlers
@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500

def is_valid_uuid(val):
    """Validate if string is a valid UUID"""
    try:
        uuid.UUID(str(val))
        return True
    except ValueError:
        return False

@app.route('/link-device-<device_id>', methods=['GET'])
def link_device_page(device_id):
    # Validate UUID format
    if not is_valid_uuid(device_id):
        flash('Invalid device ID format')
        return redirect(url_for('index'))
    
    # Simply render the template with the device_id
    return render_template('link_device.html', device_id=device_id)

@app.route('/verify-user', methods=['POST'])
def verify_user():
    try:
        # Change this to get JSON data instead of form data
        data = request.get_json()
        device_id = data['device_id']
        email = data['email']
        password = data['password']
        
        # Verify user credentials
        conn = get_db_connection()
        if not conn:
            return jsonify({'success': False, 'message': 'Database connection error'})

        cursor = conn.cursor(dictionary=True)
        try:
            # Only check user credentials in users table
            cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
            user = cursor.fetchone()
            
            if not user or not check_password_hash(user['password'], password):
                return jsonify({'success': False, 'message': 'Invalid email or password'})
            
            # If credentials are valid, check if device exists and is not linked
            cursor.execute('SELECT * FROM devices WHERE device_id = %s', (device_id,))
            device = cursor.fetchone()
            
            if device and device.get('email'):
                return jsonify({'success': False, 'message': 'Device already linked to another account'})
            
            # If everything is okay, return success
            return jsonify({'success': True, 'message': 'Credentials verified'})
            
        except mysql.connector.Error as err:
            return jsonify({'success': False, 'message': str(err)})
        finally:
            cursor.close()
            conn.close()
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

@app.route('/link-device', methods=['POST'])
def link_device():
    try:
        data = request.get_json()
        
        # Extract and validate data
        device_id = data['device_id']
        email = data['email']
        password = data['password']
        blinks_per_unit = float(data['blinks_per_unit'])
        billing_month = int(data['billing_month'])
        
        # Validate UUID format
        if not is_valid_uuid(device_id):
            return jsonify({
                'success': False,
                'message': 'Invalid device ID format'
            })
        
        # Validate billing month
        if not 1 <= billing_month <= 12:
            return jsonify({
                'success': False,
                'message': 'Invalid billing month'
            })

        conn = get_db_connection()
        if not conn:
            return jsonify({
                'success': False,
                'message': 'Database connection error'
            })

        cursor = conn.cursor(dictionary=True)
        try:
            # Begin transaction
            conn.start_transaction()
            
            # Check if device exists and is not linked
            cursor.execute('SELECT * FROM devices WHERE device_id = %s', (device_id,))
            device = cursor.fetchone()
            
            # Get user's hashed password from users table
            cursor.execute('SELECT password FROM users WHERE email = %s', (email,))
            user = cursor.fetchone()
            if not user:
                return jsonify({
                    'success': False,
                    'message': 'User not found'
                })
            
            hashed_password = user['password']  # Get the already hashed password
            
            if device:
                # Update existing device
                cursor.execute('''
                    UPDATE devices 
                    SET email = %s,
                        password = %s,
                        blinks_per_unit = %s,
                        last_billing_month = %s,
                        status = 'active'
                    WHERE device_id = %s
                ''', (email, hashed_password, blinks_per_unit, billing_month, device_id))
            else:
                # Create new device
                cursor.execute('''
                    INSERT INTO devices 
                    (device_id, email, password, blinks_per_unit, last_billing_month, status)
                    VALUES (%s, %s, %s, %s, %s, 'active')
                ''', (device_id, email, hashed_password, blinks_per_unit, billing_month))

            # Create user_data directory and CSV file
            user_data_dir = os.path.join(app.root_path, 'user_data')
            os.makedirs(user_data_dir, exist_ok=True)
            
            csv_path = os.path.join(user_data_dir, f'{device_id}.csv')
            with open(csv_path, 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['timestamp', 'units_consumed'])

            # Commit transaction
            conn.commit()
            
            return jsonify({
                'success': True,
                'message': 'Device linked successfully'
            })

        except mysql.connector.Error as err:
            conn.rollback()
            return jsonify({
                'success': False,
                'message': f'Database error: {str(err)}'
            })
        finally:
            cursor.close()
            conn.close()

    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        })

@app.route('/record-consumption/<device_id>', methods=['POST'])
def record_consumption(device_id):
    try:
        data = request.get_json()
        blinks_count = data['blinks']
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        conn = get_db_connection()
        if not conn:
            return jsonify({
                'success': False,
                'message': 'Database connection error'
            })

        cursor = conn.cursor(dictionary=True)
        try:
            # Get device's blinks_per_unit
            cursor.execute('SELECT blinks_per_unit FROM devices WHERE device_id = %s', (device_id,))
            device = cursor.fetchone()

            if not device:
                return jsonify({
                    'success': False,
                    'message': 'Device not found'
                })

            # Calculate units consumed
            blinks_per_unit = float(device['blinks_per_unit'])
            units_consumed = blinks_count / blinks_per_unit

            # Append to CSV file
            csv_path = os.path.join(app.root_path, 'user_data', f'{device_id}.csv')
            with open(csv_path, 'a', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow([
                    timestamp,
                    f'{units_consumed:.2f}'  # Format to 2 decimal places
                ])

            return jsonify({
                'success': True,
                'message': 'Consumption recorded successfully',
                'units_consumed': units_consumed
            })

        except mysql.connector.Error as err:
            return jsonify({
                'success': False,
                'message': f'Database error: {str(err)}'
            })
        finally:
            cursor.close()
            conn.close()

    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        })

if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True, port=5000)
