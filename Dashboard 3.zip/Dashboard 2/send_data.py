import requests
import random
import time
from datetime import datetime

class MeterBlinkSimulator:
    def __init__(self, server_url):
        """
        Initialize the meter blink simulator
        
        :param server_url: Base URL of the Flask server
        """
        self.server_url = server_url
        # self.device_id = "4fe714ed-20aa-4693-93b9-a5bb11f8f6e1"  # Fixed device ID
        self.device_id = "6db45f6b-5391-4789-a149-88ab461dc17d"
        print(f"Device ID: {self.device_id}")
    
    def generate_blink_data(self):
        """
        Generate simulated meter blink data
        
        :return: Dictionary with blink count only
        """
        # Generate random blink count between 1500-2200
        blinks = random.randint(1500, 2200)
        
        return {
            "blinks": blinks  # Only send blinks count
        }
    
    def send_data(self):
        """
        Send meter blink data to the server
        """
        try:
            # Generate data
            data = self.generate_blink_data()
            
            # Construct the URL with device ID
            endpoint_url = f"{self.server_url}/record-consumption/{self.device_id}"
            
            # Send POST request to server
            response = requests.post(endpoint_url, json=data)
            
            # Check response
            if response.status_code == 200:
                result = response.json()
                print(f"Data sent successfully at {datetime.now()}")
                print(f"Blinks sent: {data['blinks']}")
                print(f"Server response: {result}")
            else:
                print(f"Failed to send data. Status code: {response.status_code}")
                print(f"Response: {response.text}")
        
        except requests.exceptions.RequestException as e:
            print(f"Error sending data: {e}")
    
    def run(self, interval=60):
        """
        Run the simulator
        
        :param interval: Time between data sends in seconds (default 60 seconds)
        """
        print(f"Meter Blink Simulator Started...")
        print(f"Sending data to: {self.server_url}")
        print(f"Using Device ID: {self.device_id}")
        
        while True:
            try:
                self.send_data()
                print(f"Waiting {interval} seconds before next data send...")
                time.sleep(interval)
            except KeyboardInterrupt:
                print("\nSimulator stopped by user")
                break
            except Exception as e:
                print(f"Error in run loop: {e}")
                time.sleep(interval)

def main():
    # Base URL of the Flask server
    SERVER_URL = 'http://192.168.165.141:5000'  # Update this to match your server URL
    
    # Create simulator instance
    simulator = MeterBlinkSimulator(SERVER_URL)
    
    # Run the simulator with 60-second interval
    simulator.run(interval=60)

if __name__ == "__main__":
    main()