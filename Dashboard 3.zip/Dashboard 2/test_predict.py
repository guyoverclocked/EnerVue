import pandas as pd
import numpy as np

# Load the 2019-2020 data
data = pd.read_csv('dataset_tn.csv')
data['date'] = pd.to_datetime(data['date'])
data = data.set_index('date')
data['consumption'] = data['consumption'] * 1000000  # Convert from MU (mega units) to kWh
data['consumption_per_connection'] = data['consumption'] / 30000000  # Divide by 30 million connections

# Forecast 2023 data
start_date = pd.Timestamp('2023-01-01')
end_date = pd.Timestamp('2023-12-31')
future_dates = pd.date_range(start=start_date, end=end_date, freq='D')
forecast = pd.DataFrame(index=future_dates)

# Use a simple linear trend model to forecast 2023
model_params = data['consumption_per_connection'].loc['2019':'2020'].fit().params
forecast['consumption_per_connection'] = model_params['Intercept'] + model_params['date'] * (future_dates - pd.Timestamp('2019-01-01')).days / 365

# Round the forecasted values
forecast['consumption_per_connection'] = forecast['consumption_per_connection'].round(2)

# Save the forecast to a CSV file
forecast.to_csv('tn_electricity_forecast_2023.csv', index=True)